import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export function CaseMap() {
  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardHeader>
        <CardTitle className="text-white">Cases by Location</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="relative h-96 bg-slate-900 rounded-lg overflow-hidden">
          {/* Simplified India Map Representation */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="relative w-64 h-80">
              {/* India outline representation */}
              <div className="absolute inset-0 border-2 border-slate-600 rounded-lg opacity-50"></div>

              {/* Case markers */}
              <div className="absolute top-16 left-12 w-3 h-3 bg-red-500 rounded-full animate-pulse">
                <div className="absolute -top-6 -left-8 text-xs text-white bg-slate-700 px-2 py-1 rounded">
                  Mumbai: 5 cases
                </div>
              </div>

              <div className="absolute top-20 right-16 w-3 h-3 bg-yellow-500 rounded-full animate-pulse">
                <div className="absolute -top-6 -left-8 text-xs text-white bg-slate-700 px-2 py-1 rounded">
                  Delhi: 8 cases
                </div>
              </div>

              <div className="absolute bottom-24 left-20 w-3 h-3 bg-blue-500 rounded-full animate-pulse">
                <div className="absolute -top-6 -left-12 text-xs text-white bg-slate-700 px-2 py-1 rounded">
                  Bangalore: 3 cases
                </div>
              </div>

              <div className="absolute top-32 right-8 w-3 h-3 bg-green-500 rounded-full animate-pulse">
                <div className="absolute -top-6 -left-10 text-xs text-white bg-slate-700 px-2 py-1 rounded">
                  Chennai: 4 cases
                </div>
              </div>
            </div>
          </div>

          {/* Legend */}
          <div className="absolute bottom-4 left-4 bg-slate-800 p-3 rounded-lg">
            <div className="text-xs text-slate-400 mb-2">Case Severity</div>
            <div className="flex flex-col gap-1">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                <span className="text-xs text-white">High Risk</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                <span className="text-xs text-white">Medium Risk</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <span className="text-xs text-white">Low Risk</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="text-xs text-white">Resolved</span>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
