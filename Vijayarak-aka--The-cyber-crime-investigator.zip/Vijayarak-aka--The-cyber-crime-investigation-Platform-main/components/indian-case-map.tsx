"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export function IndianCaseMap() {
  // Real case data - only Niranjan Shelke case
  const caseData = [
    {
      id: "CR2025001",
      victim: "Niranjan Shelke",
      type: "Phishing",
      location: "Pune, Maharashtra",
      coordinates: { x: 65, y: 45 }, // Approximate position for Maharashtra
      severity: "high",
      amount: "₹15,000",
      status: "resolved",
    },
  ]

  const stateStats = [
    { state: "Maharashtra", cases: 1, color: "text-green-400" },
    { state: "Delhi", cases: 0, color: "text-slate-500" },
    { state: "Karnataka", cases: 0, color: "text-slate-500" },
    { state: "Tamil Nadu", cases: 0, color: "text-slate-500" },
    { state: "Gujarat", cases: 0, color: "text-slate-500" },
  ]

  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardHeader>
        <CardTitle className="text-white flex items-center justify-between">
          Cases by Location - India
          <Badge className="bg-blue-500/20 text-blue-400">Live Data</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="relative h-96 bg-slate-900 rounded-lg overflow-hidden">
          {/* Detailed India Map SVG */}
          <div className="absolute inset-0 flex items-center justify-center">
            <svg viewBox="0 0 200 240" className="w-full h-full" style={{ maxWidth: "300px", maxHeight: "360px" }}>
              {/* India Map Outline */}
              <path
                d="M50 40 L60 35 L75 30 L90 35 L105 40 L120 45 L135 50 L145 60 L150 75 L155 90 L160 105 L165 120 L170 135 L175 150 L180 165 L175 180 L170 195 L160 205 L145 210 L130 215 L115 220 L100 225 L85 220 L70 215 L55 210 L45 200 L40 185 L35 170 L30 155 L25 140 L20 125 L25 110 L30 95 L35 80 L40 65 L45 50 Z"
                fill="none"
                stroke="#475569"
                strokeWidth="2"
                className="opacity-60"
              />

              {/* State boundaries - simplified */}
              <g stroke="#64748b" strokeWidth="1" fill="none" className="opacity-40">
                {/* Maharashtra */}
                <path d="M60 120 L80 115 L95 120 L100 135 L95 150 L80 155 L65 150 L60 135 Z" />
                {/* Delhi */}
                <circle cx="85" cy="70" r="3" />
                {/* Karnataka */}
                <path d="M70 160 L85 155 L95 160 L100 175 L95 190 L80 195 L70 190 L65 175 Z" />
                {/* Tamil Nadu */}
                <path d="M85 195 L100 190 L110 195 L115 210 L110 225 L95 230 L85 225 L80 210 Z" />
                {/* Gujarat */}
                <path d="M40 100 L55 95 L65 100 L70 115 L65 130 L55 135 L45 130 L40 115 Z" />
              </g>

              {/* Case Markers */}
              {caseData.map((case_, idx) => (
                <g key={idx}>
                  {/* Pulsing circle for active case */}
                  <circle
                    cx={case_.coordinates.x}
                    cy={case_.coordinates.y}
                    r="8"
                    fill={case_.severity === "high" ? "#ef4444" : case_.severity === "medium" ? "#f59e0b" : "#10b981"}
                    className="animate-pulse"
                    opacity="0.8"
                  />
                  <circle cx={case_.coordinates.x} cy={case_.coordinates.y} r="4" fill="white" />

                  {/* Case Info Tooltip */}
                  <g className="opacity-0 hover:opacity-100 transition-opacity">
                    <rect
                      x={case_.coordinates.x - 35}
                      y={case_.coordinates.y - 45}
                      width="70"
                      height="35"
                      fill="#1e293b"
                      stroke="#475569"
                      rx="4"
                    />
                    <text
                      x={case_.coordinates.x}
                      y={case_.coordinates.y - 30}
                      textAnchor="middle"
                      className="fill-white text-xs font-medium"
                    >
                      {case_.victim}
                    </text>
                    <text
                      x={case_.coordinates.x}
                      y={case_.coordinates.y - 18}
                      textAnchor="middle"
                      className="fill-slate-300 text-xs"
                    >
                      {case_.type}
                    </text>
                    <text
                      x={case_.coordinates.x}
                      y={case_.coordinates.y - 6}
                      textAnchor="middle"
                      className="fill-slate-400 text-xs"
                    >
                      {case_.amount}
                    </text>
                  </g>
                </g>
              ))}

              {/* Major Cities Labels */}
              <g className="fill-slate-400 text-xs">
                <text x="85" y="75" textAnchor="middle">
                  Delhi
                </text>
                <text x="75" y="125" textAnchor="middle">
                  Mumbai
                </text>
                <text x="75" y="165" textAnchor="middle">
                  Bangalore
                </text>
                <text x="95" y="200" textAnchor="middle">
                  Chennai
                </text>
                <text x="50" y="110" textAnchor="middle">
                  Ahmedabad
                </text>
              </g>
            </svg>
          </div>

          {/* Legend */}
          <div className="absolute bottom-4 left-4 bg-slate-800/90 p-4 rounded-lg backdrop-blur-sm">
            <div className="text-xs text-slate-400 mb-3 font-medium">Case Severity & Status</div>
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
                <span className="text-xs text-white">High Risk (Active)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                <span className="text-xs text-white">Medium Risk</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                <span className="text-xs text-white">Resolved</span>
              </div>
            </div>
          </div>

          {/* State Statistics */}
          <div className="absolute bottom-4 right-4 bg-slate-800/90 p-4 rounded-lg backdrop-blur-sm">
            <div className="text-xs text-slate-400 mb-3 font-medium">State-wise Cases</div>
            <div className="space-y-1">
              {stateStats.map((state, idx) => (
                <div key={idx} className="flex items-center justify-between gap-3">
                  <span className="text-xs text-slate-300">{state.state}</span>
                  <span className={`text-xs font-medium ${state.color}`}>{state.cases}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
