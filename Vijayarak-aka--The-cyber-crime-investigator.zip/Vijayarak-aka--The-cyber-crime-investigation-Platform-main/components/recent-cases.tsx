import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Clock, CheckCircle, Eye } from "lucide-react"

// Only showing Niranjan Shelke case as resolved
const recentCases = [
  {
    id: "CR2025001",
    type: "Phishing",
    victim: "Niranjan Shelke",
    status: "resolved",
    priority: "high",
    time: "2 days ago",
    amount: "₹15,000",
    location: "Pune, Maharashtra",
    description: "Fake banking website used to steal login credentials and transfer funds",
  },
]

export function RecentCases() {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-500/20 text-yellow-400"
      case "in-progress":
        return "bg-blue-500/20 text-blue-400"
      case "resolved":
        return "bg-green-500/20 text-green-400"
      default:
        return "bg-slate-500/20 text-slate-400"
    }
  }

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case "high":
        return <CheckCircle className="w-4 h-4 text-green-400" />
      case "medium":
        return <Clock className="w-4 h-4 text-yellow-400" />
      case "low":
        return <CheckCircle className="w-4 h-4 text-green-400" />
      default:
        return <Eye className="w-4 h-4 text-slate-400" />
    }
  }

  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardHeader>
        <CardTitle className="text-white flex items-center justify-between">
          Recent Cases
          <Badge className="bg-green-500/20 text-green-400">1 Resolved</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {recentCases.length > 0 ? (
            recentCases.map((case_) => (
              <div key={case_.id} className="bg-slate-900 p-4 rounded-lg border border-slate-700">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    {getPriorityIcon(case_.priority)}
                    <span className="font-medium text-white">{case_.id}</span>
                  </div>
                  <Badge className={getStatusColor(case_.status)}>{case_.status.replace("-", " ")}</Badge>
                </div>

                <div className="space-y-2 text-sm">
                  <p className="text-slate-300">
                    <span className="text-slate-400">Type:</span> {case_.type}
                  </p>
                  <p className="text-slate-300">
                    <span className="text-slate-400">Victim:</span> {case_.victim}
                  </p>
                  <p className="text-slate-300">
                    <span className="text-slate-400">Location:</span> {case_.location}
                  </p>
                  <p className="text-slate-300">
                    <span className="text-slate-400">Amount:</span> {case_.amount}
                  </p>
                  <p className="text-slate-400 text-xs">{case_.time}</p>
                  <p className="text-slate-300 text-xs mt-2 italic">"{case_.description}"</p>
                </div>

                {case_.status === "resolved" && (
                  <div className="mt-3 p-2 bg-green-900/20 border border-green-500/30 rounded">
                    <p className="text-green-400 text-xs">
                      ✅ Case successfully resolved. Funds recovered and suspect identified.
                    </p>
                  </div>
                )}
              </div>
            ))
          ) : (
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-slate-700 rounded-full flex items-center justify-center mx-auto mb-4">
                <Eye className="w-8 h-8 text-slate-500" />
              </div>
              <p className="text-slate-400">No recent cases</p>
              <p className="text-slate-500 text-sm">Cases will appear here as they are reported</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
