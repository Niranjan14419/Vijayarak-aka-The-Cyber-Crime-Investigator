"use client"

import { useEffect, useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { TrendingUp, TrendingDown } from "lucide-react"

export function DashboardStats() {
  const [stats, setStats] = useState({
    totalCases: 0,
    resolvedCases: 0,
    inProgress: 0,
    pendingCases: 0,
  })

  const [lastUpdated, setLastUpdated] = useState(new Date())

  useEffect(() => {
    // Simulate real-time data updates
    const fetchStats = async () => {
      // In real implementation, this would fetch from your MySQL database
      // For now, we'll simulate with localStorage or start from 0
      const savedStats = localStorage.getItem("cyberrakshak-stats")
      if (savedStats) {
        setStats(JSON.parse(savedStats))
      }
      setLastUpdated(new Date())
    }

    fetchStats()

    // Update every 30 seconds
    const interval = setInterval(fetchStats, 30000)
    return () => clearInterval(interval)
  }, [])

  const statsData = [
    {
      title: "Total Cases",
      value: stats.totalCases.toString(),
      change: stats.totalCases > 0 ? "+12% from last month" : "No cases yet",
      trend: "up",
      color: "text-slate-200",
      bgColor: "bg-slate-800",
    },
    {
      title: "Resolved Cases",
      value: stats.resolvedCases.toString(),
      change: stats.resolvedCases > 0 ? "+8% from last month" : "No resolved cases",
      trend: "up",
      color: "text-green-400",
      bgColor: "bg-slate-800",
    },
    {
      title: "In Progress",
      value: stats.inProgress.toString(),
      change: stats.inProgress > 0 ? "+5% from last month" : "No active cases",
      trend: "up",
      color: "text-blue-400",
      bgColor: "bg-slate-800",
    },
    {
      title: "Pending Cases",
      value: stats.pendingCases.toString(),
      change: stats.pendingCases > 0 ? "+15% from last month" : "No pending cases",
      trend: "up",
      color: "text-yellow-400",
      bgColor: "bg-slate-800",
    },
  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {statsData.map((stat, index) => (
        <Card key={index} className={`${stat.bgColor} border-slate-700`}>
          <CardContent className="p-6 border-primary-foreground">
            <div className="flex flex-col space-y-2">
              <p className="text-sm text-slate-400">{stat.title}</p>
              <p className={`text-4xl font-bold ${stat.color}`}>{stat.value}</p>
              <div className="flex items-center gap-1 text-xs">
                {stat.trend === "up" ? (
                  <TrendingUp className="w-3 h-3 text-green-400" />
                ) : (
                  <TrendingDown className="w-3 h-3 text-red-400" />
                )}
                <span className="text-green-400">{stat.change}</span>
              </div>
              <p className="text-xs text-slate-500">
                Updated {lastUpdated.toLocaleTimeString("en-IN", { timeZone: "Asia/Kolkata" })}
              </p>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
