"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Bot, Send, X, Zap, Search, Shield } from "lucide-react"

export function AIAssistant() {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState([
    {
      type: "bot",
      content:
        "Hello! I'm your CyberRakshak AI Assistant. I can help you with cyber crime investigations, tool usage, and quick analysis. How can I assist you today?",
      timestamp: new Date(),
    },
  ])
  const [inputMessage, setInputMessage] = useState("")
  const [isTyping, setIsTyping] = useState(false)

  const quickActions = [
    { label: "Analyze Suspicious Link", icon: Shield, action: "analyze_link" },
    { label: "Trace Phone Number", icon: Search, action: "trace_phone" },
    { label: "Check Email Safety", icon: Bot, action: "check_email" },
    { label: "Report Scam", icon: Zap, action: "report_scam" },
  ]

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return

    const userMessage = {
      type: "user",
      content: inputMessage,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInputMessage("")
    setIsTyping(true)

    // Simulate AI response
    setTimeout(() => {
      const botResponse = generateAIResponse(inputMessage)
      setMessages((prev) => [
        ...prev,
        {
          type: "bot",
          content: botResponse,
          timestamp: new Date(),
        },
      ])
      setIsTyping(false)
    }, 1500)
  }

  const generateAIResponse = (input: string) => {
    const lowerInput = input.toLowerCase()

    if (lowerInput.includes("phishing") || lowerInput.includes("fake website")) {
      return "🎯 **Phishing Detection Guide:**\n\n1. **Check URL carefully** - Look for misspellings\n2. **Verify SSL certificate** - Look for padlock icon\n3. **Use our tools:**\n   - Burp Suite for web analysis\n   - VirusTotal for URL scanning\n   - Shodan for domain investigation\n\n**Quick Action:** Use our integrated Burp Suite to analyze the suspicious website structure."
    }

    if (lowerInput.includes("otp") || lowerInput.includes("sms fraud")) {
      return "📱 **OTP Fraud Investigation:**\n\n1. **Trace the number** using our Phone Tracer\n2. **Check call records** with telecom providers\n3. **Use Metasploit** for network analysis\n4. **Tools to use:**\n   - Hacker Search AI for number analysis\n   - Social media tracer\n   - Network scanner\n\n**Tip:** Most OTP frauds originate from specific regions - check our location tracer."
    }

    if (lowerInput.includes("password") || lowerInput.includes("crack") || lowerInput.includes("john")) {
      return "🔐 **Password Analysis with John the Ripper:**\n\n1. **Evidence Collection:**\n   - Gather password hashes\n   - Collect wordlists\n\n2. **John the Ripper Usage:**\n   ```bash\n   john --wordlist=passwords.txt hashes.txt\n   john --show hashes.txt\n   ```\n\n3. **Advanced Options:**\n   - Custom rules\n   - Brute force attacks\n   - Dictionary attacks\n\n**Legal Note:** Only use on authorized systems during investigations."
    }

    if (lowerInput.includes("metasploit") || lowerInput.includes("exploit")) {
      return "⚡ **Metasploit for Cyber Investigation:**\n\n1. **Network Discovery:**\n   ```bash\n   msfconsole\n   use auxiliary/scanner/portscan/tcp\n   ```\n\n2. **Vulnerability Assessment:**\n   - Scan suspect systems\n   - Identify security flaws\n\n3. **Evidence Gathering:**\n   - Network traffic analysis\n   - System fingerprinting\n\n**Warning:** Only use for authorized law enforcement investigations."
    }

    if (lowerInput.includes("burp") || lowerInput.includes("web")) {
      return "🕷️ **Burp Suite Web Analysis:**\n\n1. **Proxy Setup:**\n   - Configure browser proxy\n   - Intercept HTTP/HTTPS traffic\n\n2. **Analysis Features:**\n   - Spider crawling\n   - Vulnerability scanning\n   - Request/Response analysis\n\n3. **Investigation Use:**\n   - Analyze phishing sites\n   - Check for malicious scripts\n   - Trace communication patterns\n\n**Access:** Use our integrated Burp Suite in the Tools section."
    }

    if (lowerInput.includes("trace") || lowerInput.includes("location")) {
      return "🌍 **Location Tracing Guide:**\n\n1. **IP Address Tracing:**\n   - Use our Shodan integration\n   - Check geolocation databases\n   - Analyze network routes\n\n2. **Phone Number Tracing:**\n   - Carrier identification\n   - Location approximation\n   - Call pattern analysis\n\n3. **Tools Available:**\n   - Hacker Location Tracer\n   - Network Scanner\n   - Social Media Tracer\n\n**Try:** Our NS Hacker Search AI for comprehensive analysis."
    }

    return "🤖 I understand you need help with cyber crime investigation. Here are some things I can assist with:\n\n• **Tool Guidance** - Metasploit, John the Ripper, Burp Suite\n• **Trace Analysis** - IP, Phone, Email tracing\n• **Scam Detection** - Phishing, OTP fraud, UPI scams\n• **Evidence Collection** - Digital forensics guidance\n\nPlease be more specific about what you need help with, or use one of the quick actions below!"
  }

  const handleQuickAction = (action: string) => {
    const actionMessages = {
      analyze_link: "Please provide the suspicious link you want me to analyze for phishing or malware.",
      trace_phone: "Enter the phone number you want to trace. I'll guide you through using our tracing tools.",
      check_email: "Share the email address or content you want me to check for safety and legitimacy.",
      report_scam: "I'll help you report a scam. What type of scam are you dealing with?",
    }

    setMessages((prev) => [
      ...prev,
      {
        type: "bot",
        content: actionMessages[action as keyof typeof actionMessages],
        timestamp: new Date(),
      },
    ])
  }

  if (!isOpen) {
    return (
      <div className="fixed bottom-6 right-6 z-50">
        <Button
          onClick={() => setIsOpen(true)}
          className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 rounded-full w-14 h-14 shadow-lg"
        >
          <Bot className="w-6 h-6" />
        </Button>
      </div>
    )
  }

  return (
    <div className="fixed bottom-6 right-6 z-50 w-96 h-[600px] bg-slate-800 border border-slate-700 rounded-lg shadow-2xl flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-slate-700">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center">
            <Bot className="w-4 h-4 text-white" />
          </div>
          <div>
            <h3 className="text-white font-medium">AI Assistant</h3>
            <p className="text-xs text-green-400">● Online</p>
          </div>
        </div>
        <Button variant="ghost" size="sm" onClick={() => setIsOpen(false)} className="text-slate-400 hover:text-white">
          <X className="w-4 h-4" />
        </Button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message, idx) => (
          <div key={idx} className={`flex ${message.type === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-[80%] p-3 rounded-lg ${
                message.type === "user" ? "bg-blue-600 text-white" : "bg-slate-700 text-slate-100"
              }`}
            >
              <div className="text-sm whitespace-pre-line">{message.content}</div>
              <div className="text-xs opacity-70 mt-1">{message.timestamp.toLocaleTimeString()}</div>
            </div>
          </div>
        ))}

        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-slate-700 p-3 rounded-lg">
              <div className="flex space-x-1">
                <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"></div>
                <div
                  className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"
                  style={{ animationDelay: "0.1s" }}
                ></div>
                <div
                  className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"
                  style={{ animationDelay: "0.2s" }}
                ></div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Quick Actions */}
      <div className="p-3 border-t border-slate-700">
        <div className="grid grid-cols-2 gap-2 mb-3">
          {quickActions.map((action, idx) => (
            <Button
              key={idx}
              variant="outline"
              size="sm"
              onClick={() => handleQuickAction(action.action)}
              className="bg-slate-700 border-slate-600 text-slate-300 hover:bg-slate-600 text-xs"
            >
              <action.icon className="w-3 h-3 mr-1" />
              {action.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Input */}
      <div className="p-4 border-t border-slate-700">
        <div className="flex gap-2">
          <Input
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
            placeholder="Ask me anything about cyber investigations..."
            className="bg-slate-900 border-slate-600 text-white text-sm"
          />
          <Button onClick={handleSendMessage} size="sm" className="bg-blue-600 hover:bg-blue-700">
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  )
}
