"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Shield, Home, FileText, Settings, LogOut, Wrench } from "lucide-react"
import { Button } from "@/components/ui/button"

export function Navigation() {
  const pathname = usePathname()

  const navItems = [
    { href: "/", label: "Dashboard", icon: Home },
    { href: "/complaint", label: "File Complaint", icon: FileText },
    { href: "/tools", label: "Investigation Tools", icon: Wrench },
    { href: "/admin", label: "Admin Panel", icon: Settings },
  ]

  return (
    <nav className="bg-slate-800 border-b border-slate-700">
      <div className="container mx-auto px-6 py-4 text-destructive">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-8">
            <Link href="/" className="flex items-center gap-2">
              
              <span className="text-xl font-bold text-white">Vijayarakṣaka</span>
            </Link>

            <div className="hidden md:flex items-center gap-6">
              {navItems.map((item) => {
                const Icon = item.icon
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-colors ${
                      pathname === item.href
                        ? "bg-blue-600 text-white"
                        : "text-slate-300 hover:text-white hover:bg-slate-700"
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    {item.label}
                  </Link>
                )
              })}
            </div>
          </div>

          <div className="flex items-center gap-4">
            <Button variant="outline" className="bg-slate-700 border-slate-600 text-white hover:bg-slate-600">
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </div>
    </nav>
  )
}
