"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts"

const scamData = [
  { name: "OTP Fraud", value: 45, color: "#ef4444" },
  { name: "UPI Scam", value: 23, color: "#f59e0b" },
  { name: "Phishing", value: 18, color: "#3b82f6" },
  { name: "Investment Scam", value: 8, color: "#10b981" },
  { name: "Job Scam", value: 4, color: "#8b5cf6" },
  { name: "Others", value: 2, color: "#6b7280" },
]

export function ScamTypeChart() {
  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardHeader>
        <CardTitle className="text-white">Scam Types Distribution in India</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <PieChart>
            <Pie
              data={scamData}
              cx="50%"
              cy="50%"
              outerRadius={100}
              dataKey="value"
              label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
            >
              {scamData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip
              contentStyle={{
                backgroundColor: "#1f2937",
                border: "1px solid #374151",
                borderRadius: "8px",
                color: "#fff",
              }}
            />
          </PieChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}
