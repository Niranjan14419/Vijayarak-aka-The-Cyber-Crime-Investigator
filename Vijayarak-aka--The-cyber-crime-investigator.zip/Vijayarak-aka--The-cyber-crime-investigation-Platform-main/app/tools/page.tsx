"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Search,
  Globe,
  HandshakeIcon,
  Database,
  HardDrive,
  Network,
  Eye,
  Download,
  Play,
  Clock,
  Terminal,
  Key,
  Bug,
  Wifi,
  Lock,
} from "lucide-react"

export default function ToolsPage() {
  const [activeScans, setActiveScans] = useState<string[]>([])
  const [scanResults, setScanResults] = useState<any>({})

  const startScan = (tool: string, target: string) => {
    setActiveScans([...activeScans, `${tool}-${Date.now()}`])
    // Simulate scan completion after 3 seconds
    setTimeout(() => {
      setScanResults({
        ...scanResults,
        [tool]: {
          target,
          status: "completed",
          timestamp: new Date().toISOString(),
          results: generateMockResults(tool),
        },
      })
      setActiveScans(activeScans.filter((scan) => !scan.startsWith(tool)))
    }, 3000)
  }

  const generateMockResults = (tool: string) => {
    switch (tool) {
      case "metasploit":
        return {
          target: "192.168.1.100",
          open_ports: [22, 80, 443, 3389],
          vulnerabilities: ["CVE-2021-44228", "CVE-2022-0778", "MS17-010"],
          services: ["SSH", "HTTP", "HTTPS", "RDP"],
          os_detection: "Windows 10 Pro",
          exploitable: true,
        }
      case "john":
        return {
          hashes_cracked: 3,
          total_hashes: 5,
          passwords: ["password123", "admin", "qwerty"],
          time_taken: "2m 34s",
          wordlist_used: "rockyou.txt",
          success_rate: "60%",
        }
      case "burpsuite":
        return {
          url: "https://suspicious-site.com",
          vulnerabilities: ["XSS", "SQL Injection", "CSRF"],
          security_score: "2/10",
          cookies: 15,
          forms: 3,
          scripts: 8,
          risk_level: "High",
        }
      default:
        return {}
    }
  }

  return (
    <div className="min-h-screen bg-slate-900 text-white relative overflow-hidden">
      {/* Background Image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-10"
        style={{ backgroundImage: "url('/images/cyber-bg.png')" }}
      />

      <div className="relative z-10 container mx-auto p-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
            Advanced Investigation Tools
          </h1>
          <p className="text-slate-400 text-lg">
            Kali Linux integrated tools for professional cyber crime investigation
          </p>
          <div className="flex items-center gap-2 mt-4 p-3 bg-red-900/20 border border-red-500/30 rounded-lg">
            <HandshakeIcon className="w-5 h-5 text-red-400" />
            <p className="text-red-300 text-sm">
              These tools are for authorized law enforcement use only. Unauthorized use is illegal.
            </p>
          </div>
        </div>

        <Tabs defaultValue="kali-tools" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-slate-800 border border-slate-700">
            <TabsTrigger value="kali-tools" className="data-[state=active]:bg-red-600">
              Kali Linux Tools
            </TabsTrigger>
            <TabsTrigger value="osint" className="data-[state=active]:bg-blue-600">
              OSINT Tools
            </TabsTrigger>
            <TabsTrigger value="forensics" className="data-[state=active]:bg-purple-600">
              Digital Forensics
            </TabsTrigger>
            <TabsTrigger value="network" className="data-[state=active]:bg-green-600">
              Network Analysis
            </TabsTrigger>
          </TabsList>

          {/* Kali Linux Tools Tab */}
          <TabsContent value="kali-tools" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Metasploit */}
              <Card className="bg-slate-800/90 border-slate-700 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3 text-white">
                    <div className="p-2 bg-red-600 rounded-lg">
                      <Bug className="w-6 h-6" />
                    </div>
                    Metasploit Framework
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-slate-400 text-sm">
                    Advanced penetration testing framework for vulnerability assessment and exploitation.
                  </p>

                  <MetasploitInterface onScan={(target) => startScan("metasploit", target)} />

                  {scanResults.metasploit && (
                    <div className="bg-slate-900 p-4 rounded-lg">
                      <h4 className="font-semibold text-red-400 mb-2">Metasploit Scan Results:</h4>
                      <div className="space-y-2 text-sm">
                        <p>
                          <span className="text-slate-400">Target:</span> {scanResults.metasploit.results.target}
                        </p>
                        <p>
                          <span className="text-slate-400">OS:</span> {scanResults.metasploit.results.os_detection}
                        </p>
                        <p>
                          <span className="text-slate-400">Open Ports:</span>{" "}
                          {scanResults.metasploit.results.open_ports.join(", ")}
                        </p>
                        <div className="flex flex-wrap gap-1 mt-2">
                          {scanResults.metasploit.results.vulnerabilities.map((vuln: string, idx: number) => (
                            <Badge key={idx} className="bg-red-500/20 text-red-400 text-xs">
                              {vuln}
                            </Badge>
                          ))}
                        </div>
                        <Badge
                          className={`${scanResults.metasploit.results.exploitable ? "bg-red-500/20 text-red-400" : "bg-green-500/20 text-green-400"}`}
                        >
                          {scanResults.metasploit.results.exploitable ? "Exploitable" : "Secure"}
                        </Badge>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* John the Ripper */}
              <Card className="bg-slate-800/90 border-slate-700 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3 text-white">
                    <div className="p-2 bg-orange-600 rounded-lg">
                      <Key className="w-6 h-6" />
                    </div>
                    John the Ripper
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-slate-400 text-sm">
                    Fast password cracker for analyzing password security in investigations.
                  </p>

                  <JohnInterface onScan={(target) => startScan("john", target)} />

                  {scanResults.john && (
                    <div className="bg-slate-900 p-4 rounded-lg">
                      <h4 className="font-semibold text-orange-400 mb-2">Password Analysis Results:</h4>
                      <div className="space-y-2 text-sm">
                        <p>
                          <span className="text-slate-400">Hashes Cracked:</span>{" "}
                          {scanResults.john.results.hashes_cracked}/{scanResults.john.results.total_hashes}
                        </p>
                        <p>
                          <span className="text-slate-400">Success Rate:</span> {scanResults.john.results.success_rate}
                        </p>
                        <p>
                          <span className="text-slate-400">Time Taken:</span> {scanResults.john.results.time_taken}
                        </p>
                        <div className="mt-2">
                          <p className="text-slate-400 text-xs mb-1">Cracked Passwords:</p>
                          {scanResults.john.results.passwords.map((pwd: string, idx: number) => (
                            <Badge key={idx} className="bg-orange-500/20 text-orange-400 text-xs mr-1">
                              {pwd}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Burp Suite */}
              <Card className="bg-slate-800/90 border-slate-700 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3 text-white">
                    <div className="p-2 bg-blue-600 rounded-lg">
                      <Globe className="w-6 h-6" />
                    </div>
                    Burp Suite Professional
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-slate-400 text-sm">
                    Web application security testing platform for analyzing suspicious websites.
                  </p>

                  <BurpSuiteInterface onScan={(target) => startScan("burpsuite", target)} />

                  {scanResults.burpsuite && (
                    <div className="bg-slate-900 p-4 rounded-lg">
                      <h4 className="font-semibold text-blue-400 mb-2">Web Security Analysis:</h4>
                      <div className="space-y-2 text-sm">
                        <p>
                          <span className="text-slate-400">URL:</span> {scanResults.burpsuite.results.url}
                        </p>
                        <p>
                          <span className="text-slate-400">Security Score:</span>{" "}
                          {scanResults.burpsuite.results.security_score}
                        </p>
                        <p>
                          <span className="text-slate-400">Risk Level:</span>
                          <Badge className="bg-red-500/20 text-red-400 ml-2">
                            {scanResults.burpsuite.results.risk_level}
                          </Badge>
                        </p>
                        <div className="flex flex-wrap gap-1 mt-2">
                          {scanResults.burpsuite.results.vulnerabilities.map((vuln: string, idx: number) => (
                            <Badge key={idx} className="bg-red-500/20 text-red-400 text-xs">
                              {vuln}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Additional Kali Tools */}
              <Card className="bg-slate-800/90 border-slate-700 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3 text-white">
                    <div className="p-2 bg-purple-600 rounded-lg">
                      <Terminal className="w-6 h-6" />
                    </div>
                    Additional Kali Tools
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="grid grid-cols-1 gap-3">
                    <Button
                      variant="outline"
                      className="bg-slate-700 border-slate-600 text-white hover:bg-slate-600 justify-start"
                    >
                      <Terminal className="w-4 h-4 mr-2" />
                      Nmap - Network Discovery
                    </Button>
                    <Button
                      variant="outline"
                      className="bg-slate-700 border-slate-600 text-white hover:bg-slate-600 justify-start"
                    >
                      <Wifi className="w-4 h-4 mr-2" />
                      Aircrack-ng - WiFi Security
                    </Button>
                    <Button
                      variant="outline"
                      className="bg-slate-700 border-slate-600 text-white hover:bg-slate-600 justify-start"
                    >
                      <Lock className="w-4 h-4 mr-2" />
                      Hashcat - Advanced Password Recovery
                    </Button>
                    <Button
                      variant="outline"
                      className="bg-slate-700 border-slate-600 text-white hover:bg-slate-600 justify-start"
                    >
                      <Network className="w-4 h-4 mr-2" />
                      Wireshark - Packet Analysis
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* OSINT Tools Tab */}
          <TabsContent value="osint" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Shodan Integration */}
              <Card className="bg-slate-800/90 border-slate-700 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3 text-white">
                    <div className="p-2 bg-red-600 rounded-lg">
                      <Search className="w-6 h-6" />
                    </div>
                    Shodan - Internet Scanner
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-slate-400 text-sm">
                    Search for devices connected to the internet. Find open ports, services, and vulnerabilities.
                  </p>
                  <ShodanInterface onScan={(target) => startScan("shodan", target)} />
                </CardContent>
              </Card>

              {/* SpiderFoot Integration */}
              <Card className="bg-slate-800/90 border-slate-700 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3 text-white">
                    <div className="p-2 bg-orange-600 rounded-lg">
                      <Globe className="w-6 h-6" />
                    </div>
                    SpiderFoot - OSINT Automation
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-slate-400 text-sm">
                    Automated OSINT collection. Gather intelligence from 200+ data sources.
                  </p>
                  <SpiderFootInterface onScan={(target) => startScan("spiderfoot", target)} />
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Digital Forensics Tab */}
          <TabsContent value="forensics" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Autopsy */}
              <Card className="bg-slate-800/90 border-slate-700 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3 text-white">
                    <div className="p-2 bg-green-600 rounded-lg">
                      <HardDrive className="w-6 h-6" />
                    </div>
                    Autopsy - Digital Forensics
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-slate-400 text-sm">
                    Open source digital forensics platform. Analyze hard drives and mobile devices.
                  </p>
                  <AutopsyInterface />
                </CardContent>
              </Card>

              {/* FTK Imager */}
              <Card className="bg-slate-800/90 border-slate-700 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3 text-white">
                    <div className="p-2 bg-indigo-600 rounded-lg">
                      <Database className="w-6 h-6" />
                    </div>
                    FTK Imager - Disk Imaging
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-slate-400 text-sm">
                    Create forensic images of hard drives, removable media, and memory.
                  </p>
                  <FTKInterface />
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Network Analysis Tab */}
          <TabsContent value="network" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Wireshark */}
              <Card className="bg-slate-800/90 border-slate-700 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3 text-white">
                    <div className="p-2 bg-blue-600 rounded-lg">
                      <Network className="w-6 h-6" />
                    </div>
                    Wireshark - Packet Analysis
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-slate-400 text-sm">
                    Network protocol analyzer. Capture and analyze network traffic in real-time.
                  </p>
                  <WiresharkInterface />
                </CardContent>
              </Card>

              {/* Nmap */}
              <Card className="bg-slate-800/90 border-slate-700 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3 text-white">
                    <div className="p-2 bg-green-600 rounded-lg">
                      <Search className="w-6 h-6" />
                    </div>
                    Nmap - Network Discovery
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-slate-400 text-sm">
                    Network discovery and security auditing. Scan for open ports and services.
                  </p>
                  <NmapInterface />
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Active Scans Status */}
        {activeScans.length > 0 && (
          <Card className="bg-slate-800/90 border-slate-700 backdrop-blur-sm mt-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-white">
                <Clock className="w-5 h-5 animate-spin" />
                Active Scans
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {activeScans.map((scan, idx) => (
                  <div key={idx} className="flex items-center gap-3 bg-slate-900 p-3 rounded-lg">
                    <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
                    <span className="text-slate-300">Running {scan.split("-")[0]}...</span>
                    <Badge className="bg-blue-500/20 text-blue-400">In Progress</Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}

// Tool Interfaces
function MetasploitInterface({ onScan }: { onScan: (target: string) => void }) {
  const [target, setTarget] = useState("")

  return (
    <div className="space-y-3">
      <div>
        <Label className="text-slate-300">Target IP/Network</Label>
        <Input
          value={target}
          onChange={(e) => setTarget(e.target.value)}
          placeholder="192.168.1.0/24"
          className="bg-slate-900 border-slate-600 text-white"
        />
      </div>
      <Button onClick={() => onScan(target)} className="w-full bg-red-600 hover:bg-red-700" disabled={!target}>
        <Bug className="w-4 h-4 mr-2" />
        Launch Metasploit Scan
      </Button>
      <div className="text-xs text-slate-500">Performs vulnerability assessment and exploitation testing</div>
    </div>
  )
}

function JohnInterface({ onScan }: { onScan: (target: string) => void }) {
  const [hashFile, setHashFile] = useState("")

  return (
    <div className="space-y-3">
      <div>
        <Label className="text-slate-300">Hash File Path</Label>
        <Input
          value={hashFile}
          onChange={(e) => setHashFile(e.target.value)}
          placeholder="/path/to/hashes.txt"
          className="bg-slate-900 border-slate-600 text-white"
        />
      </div>
      <Button
        onClick={() => onScan(hashFile)}
        className="w-full bg-orange-600 hover:bg-orange-700"
        disabled={!hashFile}
      >
        <Key className="w-4 h-4 mr-2" />
        Start Password Cracking
      </Button>
      <div className="text-xs text-slate-500">Uses dictionary and brute force attacks to crack password hashes</div>
    </div>
  )
}

function BurpSuiteInterface({ onScan }: { onScan: (target: string) => void }) {
  const [url, setUrl] = useState("")

  return (
    <div className="space-y-3">
      <div>
        <Label className="text-slate-300">Target URL</Label>
        <Input
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="https://suspicious-website.com"
          className="bg-slate-900 border-slate-600 text-white"
        />
      </div>
      <Button onClick={() => onScan(url)} className="w-full bg-blue-600 hover:bg-blue-700" disabled={!url}>
        <Globe className="w-4 h-4 mr-2" />
        Analyze Web Application
      </Button>
      <div className="text-xs text-slate-500">Performs comprehensive web application security testing</div>
    </div>
  )
}

function ShodanInterface({ onScan }: { onScan: (target: string) => void }) {
  const [target, setTarget] = useState("")

  return (
    <div className="space-y-3">
      <div>
        <Label className="text-slate-300">IP Address or Domain</Label>
        <Input
          value={target}
          onChange={(e) => setTarget(e.target.value)}
          placeholder="192.168.1.1 or example.com"
          className="bg-slate-900 border-slate-600 text-white"
        />
      </div>
      <Button onClick={() => onScan(target)} className="w-full bg-red-600 hover:bg-red-700" disabled={!target}>
        <Play className="w-4 h-4 mr-2" />
        Start Shodan Scan
      </Button>
    </div>
  )
}

function SpiderFootInterface({ onScan }: { onScan: (target: string) => void }) {
  const [target, setTarget] = useState("")

  return (
    <div className="space-y-3">
      <div>
        <Label className="text-slate-300">Domain or Email</Label>
        <Input
          value={target}
          onChange={(e) => setTarget(e.target.value)}
          placeholder="example.com or email@domain.com"
          className="bg-slate-900 border-slate-600 text-white"
        />
      </div>
      <Button onClick={() => onScan(target)} className="w-full bg-orange-600 hover:bg-orange-700" disabled={!target}>
        <Play className="w-4 h-4 mr-2" />
        Start SpiderFoot Scan
      </Button>
    </div>
  )
}

function AutopsyInterface() {
  return (
    <div className="space-y-3">
      <div className="bg-slate-900 p-3 rounded-lg">
        <p className="text-sm text-slate-400 mb-2">Status: Ready</p>
        <div className="flex gap-2">
          <Button size="sm" className="bg-green-600 hover:bg-green-700">
            <Play className="w-4 h-4 mr-2" />
            New Case
          </Button>
          <Button size="sm" variant="outline" className="bg-slate-700 border-slate-600 text-white">
            <Download className="w-4 h-4 mr-2" />
            Load Image
          </Button>
        </div>
      </div>
    </div>
  )
}

function FTKInterface() {
  return (
    <div className="space-y-3">
      <div className="bg-slate-900 p-3 rounded-lg">
        <p className="text-sm text-slate-400 mb-2">FTK Imager Status: Ready</p>
        <div className="flex gap-2">
          <Button size="sm" className="bg-indigo-600 hover:bg-indigo-700">
            <HardDrive className="w-4 h-4 mr-2" />
            Create Image
          </Button>
          <Button size="sm" variant="outline" className="bg-slate-700 border-slate-600 text-white">
            <Eye className="w-4 h-4 mr-2" />
            View Image
          </Button>
        </div>
      </div>
    </div>
  )
}

function WiresharkInterface() {
  return (
    <div className="space-y-3">
      <div className="bg-slate-900 p-3 rounded-lg">
        <p className="text-sm text-slate-400 mb-2">Network Interface: eth0</p>
        <div className="flex gap-2">
          <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
            <Play className="w-4 h-4 mr-2" />
            Start Capture
          </Button>
          <Button size="sm" variant="outline" className="bg-slate-700 border-slate-600 text-white">
            <Download className="w-4 h-4 mr-2" />
            Load PCAP
          </Button>
        </div>
      </div>
    </div>
  )
}

function NmapInterface() {
  const [target, setTarget] = useState("")

  return (
    <div className="space-y-3">
      <div>
        <Label className="text-slate-300">Target IP/Range</Label>
        <Input
          value={target}
          onChange={(e) => setTarget(e.target.value)}
          placeholder="192.168.1.0/24"
          className="bg-slate-900 border-slate-600 text-white"
        />
      </div>
      <Button className="w-full bg-green-600 hover:bg-green-700" disabled={!target}>
        <Search className="w-4 h-4 mr-2" />
        Start Network Scan
      </Button>
    </div>
  )
}
