"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Shield, Eye, EyeOff, Phone, Mail } from "lucide-react"
import Link from "next/link"

export default function LoginPage() {
  const [showPassword, setShowPassword] = useState(false)
  const [loginType, setLoginType] = useState<"admin" | "public">("public")
  const [formData, setFormData] = useState({
    identifier: "",
    password: "",
    otp: "",
  })
  const [step, setStep] = useState<"login" | "otp">("login")

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    if (loginType === "public") {
      // For public users, send OTP
      setStep("otp")
    } else {
      // For admin, direct login
      // Redirect to admin dashboard
      window.location.href = "/admin"
    }
  }

  const handleOTPVerification = (e: React.FormEvent) => {
    e.preventDefault()
    // Verify OTP and redirect to public dashboard
    window.location.href = "/public"
  }

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-6">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <Shield className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
            CyberRakshak
          </h1>
          <p className="text-slate-400 mt-2">Secure Login Portal</p>
        </div>

        {/* Login Type Selection */}
        <div className="flex mb-6 bg-slate-800 rounded-lg p-1">
          <button
            onClick={() => setLoginType("public")}
            className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
              loginType === "public" ? "bg-blue-600 text-white" : "text-slate-400 hover:text-white"
            }`}
          >
            Public User
          </button>
          <button
            onClick={() => setLoginType("admin")}
            className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
              loginType === "admin" ? "bg-red-600 text-white" : "text-slate-400 hover:text-white"
            }`}
          >
            Admin/Police
          </button>
        </div>

        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white text-center">
              {loginType === "admin" ? "Admin Login" : "Citizen Login"}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {step === "login" ? (
              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <Label htmlFor="identifier" className="text-slate-300">
                    {loginType === "admin" ? "Employee ID / Email" : "Mobile Number / Email"}
                  </Label>
                  <div className="relative">
                    {loginType === "public" ? (
                      <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                    ) : (
                      <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                    )}
                    <Input
                      id="identifier"
                      value={formData.identifier}
                      onChange={(e) => setFormData({ ...formData, identifier: e.target.value })}
                      className="bg-slate-900 border-slate-600 text-white pl-10"
                      placeholder={
                        loginType === "admin" ? "Enter employee ID or email" : "Enter mobile number or email"
                      }
                      required
                    />
                  </div>
                </div>

                {loginType === "admin" && (
                  <div>
                    <Label htmlFor="password" className="text-slate-300">
                      Password
                    </Label>
                    <div className="relative">
                      <Input
                        id="password"
                        type={showPassword ? "text" : "password"}
                        value={formData.password}
                        onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                        className="bg-slate-900 border-slate-600 text-white pr-10"
                        placeholder="Enter your password"
                        required
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-400 hover:text-white"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                )}

                <Button
                  type="submit"
                  className={`w-full ${
                    loginType === "admin" ? "bg-red-600 hover:bg-red-700" : "bg-blue-600 hover:bg-blue-700"
                  }`}
                >
                  {loginType === "admin" ? "Login" : "Send OTP"}
                </Button>

                {loginType === "admin" && (
                  <div className="text-center">
                    <Link href="/auth/forgot-password" className="text-blue-400 hover:text-blue-300 text-sm">
                      Forgot Password?
                    </Link>
                  </div>
                )}
              </form>
            ) : (
              <form onSubmit={handleOTPVerification} className="space-y-4">
                <div className="text-center mb-4">
                  <p className="text-slate-300">OTP sent to {formData.identifier}</p>
                  <p className="text-slate-400 text-sm">Enter the 6-digit code</p>
                </div>

                <div>
                  <Label htmlFor="otp" className="text-slate-300">
                    Enter OTP
                  </Label>
                  <Input
                    id="otp"
                    value={formData.otp}
                    onChange={(e) => setFormData({ ...formData, otp: e.target.value })}
                    className="bg-slate-900 border-slate-600 text-white text-center text-lg tracking-widest"
                    placeholder="000000"
                    maxLength={6}
                    required
                  />
                </div>

                <Button type="submit" className="w-full bg-green-600 hover:bg-green-700">
                  Verify OTP
                </Button>

                <div className="text-center">
                  <button
                    type="button"
                    onClick={() => setStep("login")}
                    className="text-blue-400 hover:text-blue-300 text-sm"
                  >
                    Back to Login
                  </button>
                </div>
              </form>
            )}
          </CardContent>
        </Card>

        {/* Register Link for Public Users */}
        {loginType === "public" && (
          <div className="text-center mt-6">
            <p className="text-slate-400">
              New user?{" "}
              <Link href="/auth/register" className="text-blue-400 hover:text-blue-300">
                Create Account
              </Link>
            </p>
          </div>
        )}

        {/* Emergency Contact */}
        <div className="text-center mt-8 p-4 bg-red-900/20 border border-red-500/30 rounded-lg">
          <p className="text-red-300 text-sm">
            Emergency? Call <strong>1930</strong> (Cyber Crime Helpline)
          </p>
        </div>
      </div>
    </div>
  )
}
