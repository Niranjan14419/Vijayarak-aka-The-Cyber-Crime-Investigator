"use client"

import { Label } from "@/components/ui/label"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Filter, Download, Eye, Play, Shield } from "lucide-react"

const complaints = [
  {
    id: "CR001",
    name: "Rajesh Kumar",
    email: "rajesh@email.com",
    phone: "+91-9876543210",
    type: "OTP Fraud",
    amount: "₹25,000",
    status: "pending",
    priority: "high",
    date: "2025-01-20",
    description: "Received fake OTP call claiming to be from bank...",
  },
  {
    id: "CR002",
    name: "Priya Sharma",
    email: "priya@email.com",
    phone: "+91-9876543211",
    type: "Telegram Scam",
    amount: "₹15,000",
    status: "in-progress",
    priority: "medium",
    date: "2025-01-19",
    description: "Investment scam through Telegram group...",
  },
  {
    id: "CR003",
    name: "Amit Singh",
    email: "amit@email.com",
    phone: "+91-9876543212",
    type: "Phishing",
    amount: "₹5,000",
    status: "resolved",
    priority: "low",
    date: "2025-01-18",
    description: "Fake banking website used to steal credentials...",
  },
]

export default function AdminDashboard() {
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [selectedComplaint, setSelectedComplaint] = useState<any>(null)

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-500/20 text-yellow-400"
      case "in-progress":
        return "bg-blue-500/20 text-blue-400"
      case "resolved":
        return "bg-green-500/20 text-green-400"
      default:
        return "bg-slate-500/20 text-slate-400"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-500/20 text-red-400"
      case "medium":
        return "bg-yellow-500/20 text-yellow-400"
      case "low":
        return "bg-green-500/20 text-green-400"
      default:
        return "bg-slate-500/20 text-slate-400"
    }
  }

  const runOSINTScan = (complaintId: string) => {
    // Simulate OSINT scan
    alert(`Running OSINT scan for complaint ${complaintId}...`)
  }

  const updateStatus = (complaintId: string, newStatus: string) => {
    // Update complaint status
    console.log(`Updating ${complaintId} to ${newStatus}`)
  }

  return (
    <div className="min-h-screen bg-slate-900 text-white">
      <div className="container mx-auto p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Shield className="w-8 h-8 text-blue-400" />
            <h1 className="text-3xl font-bold">Admin Dashboard</h1>
          </div>
          <Button className="bg-blue-600 hover:bg-blue-700">
            <Download className="w-4 h-4 mr-2" />
            Export Report
          </Button>
        </div>

        {/* Filters */}
        <Card className="bg-slate-800 border-slate-700 mb-6">
          <CardContent className="p-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                  <Input
                    placeholder="Search complaints..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 bg-slate-900 border-slate-600 text-white"
                  />
                </div>
              </div>

              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-48 bg-slate-900 border-slate-600 text-white">
                  <Filter className="w-4 h-4 mr-2" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-600">
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="in-progress">In Progress</SelectItem>
                  <SelectItem value="resolved">Resolved</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Complaints Table */}
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white">All Complaints</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-slate-700">
                    <th className="text-left p-3 text-slate-300">ID</th>
                    <th className="text-left p-3 text-slate-300">Victim</th>
                    <th className="text-left p-3 text-slate-300">Type</th>
                    <th className="text-left p-3 text-slate-300">Amount</th>
                    <th className="text-left p-3 text-slate-300">Status</th>
                    <th className="text-left p-3 text-slate-300">Priority</th>
                    <th className="text-left p-3 text-slate-300">Date</th>
                    <th className="text-left p-3 text-slate-300">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {complaints.map((complaint) => (
                    <tr key={complaint.id} className="border-b border-slate-700 hover:bg-slate-700/50">
                      <td className="p-3 font-mono text-blue-400">{complaint.id}</td>
                      <td className="p-3">
                        <div>
                          <div className="font-medium text-white">{complaint.name}</div>
                          <div className="text-sm text-slate-400">{complaint.email}</div>
                        </div>
                      </td>
                      <td className="p-3 text-slate-300">{complaint.type}</td>
                      <td className="p-3 text-slate-300">{complaint.amount}</td>
                      <td className="p-3">
                        <Badge className={getStatusColor(complaint.status)}>{complaint.status.replace("-", " ")}</Badge>
                      </td>
                      <td className="p-3">
                        <Badge className={getPriorityColor(complaint.priority)}>{complaint.priority}</Badge>
                      </td>
                      <td className="p-3 text-slate-300">{complaint.date}</td>
                      <td className="p-3">
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            className="bg-slate-700 border-slate-600 text-white hover:bg-slate-600"
                            onClick={() => setSelectedComplaint(complaint)}
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            className="bg-blue-600 border-blue-500 text-white hover:bg-blue-700"
                            onClick={() => runOSINTScan(complaint.id)}
                          >
                            <Play className="w-4 h-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Complaint Detail Modal */}
        {selectedComplaint && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <Card className="bg-slate-800 border-slate-700 max-w-2xl w-full max-h-[80vh] overflow-y-auto">
              <CardHeader>
                <CardTitle className="text-white flex items-center justify-between">
                  Complaint Details - {selectedComplaint.id}
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setSelectedComplaint(null)}
                    className="bg-slate-700 border-slate-600 text-white"
                  >
                    Close
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-slate-400">Victim Name</Label>
                    <p className="text-white">{selectedComplaint.name}</p>
                  </div>
                  <div>
                    <Label className="text-slate-400">Phone</Label>
                    <p className="text-white">{selectedComplaint.phone}</p>
                  </div>
                  <div>
                    <Label className="text-slate-400">Fraud Type</Label>
                    <p className="text-white">{selectedComplaint.type}</p>
                  </div>
                  <div>
                    <Label className="text-slate-400">Amount Lost</Label>
                    <p className="text-white">{selectedComplaint.amount}</p>
                  </div>
                </div>

                <div>
                  <Label className="text-slate-400">Description</Label>
                  <p className="text-white mt-1">{selectedComplaint.description}</p>
                </div>

                <div className="flex gap-4">
                  <Select onValueChange={(value) => updateStatus(selectedComplaint.id, value)}>
                    <SelectTrigger className="bg-slate-900 border-slate-600 text-white">
                      <SelectValue placeholder="Update Status" />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-800 border-slate-600">
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="in-progress">In Progress</SelectItem>
                      <SelectItem value="resolved">Resolved</SelectItem>
                    </SelectContent>
                  </Select>

                  <Button className="bg-green-600 hover:bg-green-700">
                    <Download className="w-4 h-4 mr-2" />
                    Generate Report
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}
