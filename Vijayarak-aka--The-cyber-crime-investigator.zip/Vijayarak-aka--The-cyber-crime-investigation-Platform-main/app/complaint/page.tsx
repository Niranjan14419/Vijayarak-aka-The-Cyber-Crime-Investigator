"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Upload, FileText, ImageIcon, AlertCircle } from "lucide-react"

export default function ComplaintPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    fraudType: "",
    description: "",
    suspectDetails: "",
    amount: "",
  })

  const [files, setFiles] = useState<File[]>([])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle form submission
    console.log("Form submitted:", formData, files)
  }

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFiles(Array.from(e.target.files))
    }
  }

  return (
    <div className="min-h-screen bg-slate-900 text-white">
      <div className="container mx-auto p-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">File a Cyber Crime Complaint</h1>
          <p className="text-slate-400">Report cyber fraud and help us protect others from similar crimes</p>
        </div>

        <form onSubmit={handleSubmit} className="max-w-4xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Personal Information */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <AlertCircle className="w-5 h-5" />
                  Personal Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="name" className="text-slate-300">
                    Full Name *
                  </Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="bg-slate-900 border-slate-600 text-white"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="email" className="text-slate-300">
                    Email Address *
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="bg-slate-900 border-slate-600 text-white"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="phone" className="text-slate-300">
                    Phone Number *
                  </Label>
                  <Input
                    id="phone"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="bg-slate-900 border-slate-600 text-white"
                    required
                  />
                </div>
              </CardContent>
            </Card>

            {/* Fraud Details */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Fraud Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="fraudType" className="text-slate-300">
                    Type of Fraud *
                  </Label>
                  <Select onValueChange={(value) => setFormData({ ...formData, fraudType: value })}>
                    <SelectTrigger className="bg-slate-900 border-slate-600 text-white">
                      <SelectValue placeholder="Select fraud type" />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-800 border-slate-600">
                      <SelectItem value="otp-fraud">OTP Fraud</SelectItem>
                      <SelectItem value="telegram-scam">Telegram Scam</SelectItem>
                      <SelectItem value="phishing">Phishing</SelectItem>
                      <SelectItem value="upi-fraud">UPI Fraud</SelectItem>
                      <SelectItem value="investment-scam">Investment Scam</SelectItem>
                      <SelectItem value="job-scam">Job Scam</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="amount" className="text-slate-300">
                    Amount Lost (₹)
                  </Label>
                  <Input
                    id="amount"
                    type="number"
                    value={formData.amount}
                    onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                    className="bg-slate-900 border-slate-600 text-white"
                    placeholder="Enter amount in rupees"
                  />
                </div>

                <div>
                  <Label htmlFor="suspectDetails" className="text-slate-300">
                    Suspect Details
                  </Label>
                  <Textarea
                    id="suspectDetails"
                    value={formData.suspectDetails}
                    onChange={(e) => setFormData({ ...formData, suspectDetails: e.target.value })}
                    className="bg-slate-900 border-slate-600 text-white"
                    placeholder="Phone numbers, Telegram usernames, IP addresses, etc."
                    rows={3}
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Incident Description */}
          <Card className="bg-slate-800 border-slate-700 mt-6">
            <CardHeader>
              <CardTitle className="text-white">Incident Description</CardTitle>
            </CardHeader>
            <CardContent>
              <div>
                <Label htmlFor="description" className="text-slate-300">
                  Detailed Description *
                </Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="bg-slate-900 border-slate-600 text-white mt-2"
                  placeholder="Describe the incident in detail - what happened, when, how you were contacted, etc."
                  rows={6}
                  required
                />
              </div>
            </CardContent>
          </Card>

          {/* File Upload */}
          <Card className="bg-slate-800 border-slate-700 mt-6">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Upload className="w-5 h-5" />
                Evidence Upload
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="border-2 border-dashed border-slate-600 rounded-lg p-6 text-center">
                <input
                  type="file"
                  multiple
                  accept=".pdf,.jpg,.jpeg,.png,.txt,.doc,.docx"
                  onChange={handleFileUpload}
                  className="hidden"
                  id="file-upload"
                />
                <label htmlFor="file-upload" className="cursor-pointer">
                  <Upload className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                  <p className="text-slate-300 mb-2">Click to upload files or drag and drop</p>
                  <p className="text-slate-500 text-sm">Screenshots, chats, PDFs, documents (Max 10MB each)</p>
                </label>
              </div>

              {files.length > 0 && (
                <div className="mt-4 space-y-2">
                  <p className="text-slate-300 font-medium">Uploaded Files:</p>
                  {files.map((file, index) => (
                    <div key={index} className="flex items-center gap-2 bg-slate-900 p-2 rounded">
                      {file.type.startsWith("image/") ? (
                        <ImageIcon className="w-4 h-4 text-blue-400" />
                      ) : (
                        <FileText className="w-4 h-4 text-green-400" />
                      )}
                      <span className="text-slate-300 text-sm">{file.name}</span>
                      <span className="text-slate-500 text-xs">({(file.size / 1024 / 1024).toFixed(2)} MB)</span>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Submit Button */}
          <div className="mt-8 flex justify-center">
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 text-lg">
              Submit Complaint
            </Button>
          </div>
        </form>
      </div>
    </div>
  )
}
