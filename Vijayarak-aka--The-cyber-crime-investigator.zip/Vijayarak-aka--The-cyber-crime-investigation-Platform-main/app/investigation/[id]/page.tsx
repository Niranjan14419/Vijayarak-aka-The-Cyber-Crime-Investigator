"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { FileText, Download, Eye, Clock, Search, Globe, Network, HardDrive, Shield } from "lucide-react"

export default function InvestigationPage({ params }: { params: { id: string } }) {
  const [activeTools, setActiveTools] = useState<string[]>([])

  const caseData = {
    id: params.id,
    victim: "Rajesh Kumar",
    type: "OTP Fraud",
    amount: "₹25,000",
    status: "in-progress",
    priority: "high",
    description:
      "Victim received a call claiming to be from SBI bank asking for OTP to update KYC details. After providing OTP, ₹25,000 was debited from account.",
    evidence: [
      { name: "Call Recording", type: "audio", size: "2.3 MB" },
      { name: "Bank Statement", type: "pdf", size: "1.1 MB" },
      { name: "SMS Screenshots", type: "image", size: "0.8 MB" },
    ],
    suspect: {
      phone: "+91-8765432109",
      bankAccount: "XXXX-XXXX-1234",
      location: "Unknown",
    },
  }

  const runTool = (tool: string) => {
    setActiveTools([...activeTools, tool])
    // Simulate tool completion
    setTimeout(() => {
      setActiveTools(activeTools.filter((t) => t !== tool))
    }, 5000)
  }

  return (
    <div className="min-h-screen bg-slate-900 text-white">
      <div className="container mx-auto p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold">Investigation: {caseData.id}</h1>
            <p className="text-slate-400">Comprehensive analysis and evidence collection</p>
          </div>
          <div className="flex gap-3">
            <Button className="bg-green-600 hover:bg-green-700">
              <Download className="w-4 h-4 mr-2" />
              Generate Report
            </Button>
            <Badge
              className={`px-3 py-1 ${
                caseData.priority === "high"
                  ? "bg-red-500/20 text-red-400"
                  : caseData.priority === "medium"
                    ? "bg-yellow-500/20 text-yellow-400"
                    : "bg-green-500/20 text-green-400"
              }`}
            >
              {caseData.priority.toUpperCase()} PRIORITY
            </Badge>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Case Overview */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Case Overview</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-slate-400 text-sm">Victim</p>
                    <p className="text-white font-medium">{caseData.victim}</p>
                  </div>
                  <div>
                    <p className="text-slate-400 text-sm">Fraud Type</p>
                    <p className="text-white font-medium">{caseData.type}</p>
                  </div>
                  <div>
                    <p className="text-slate-400 text-sm">Amount Lost</p>
                    <p className="text-white font-medium">{caseData.amount}</p>
                  </div>
                  <div>
                    <p className="text-slate-400 text-sm">Status</p>
                    <Badge className="bg-blue-500/20 text-blue-400">{caseData.status}</Badge>
                  </div>
                </div>
                <div>
                  <p className="text-slate-400 text-sm mb-2">Description</p>
                  <p className="text-slate-300">{caseData.description}</p>
                </div>
              </CardContent>
            </Card>

            {/* Investigation Tools */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Investigation Tools</CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="osint">
                  <TabsList className="grid w-full grid-cols-3 bg-slate-700">
                    <TabsTrigger value="osint">OSINT</TabsTrigger>
                    <TabsTrigger value="forensics">Forensics</TabsTrigger>
                    <TabsTrigger value="network">Network</TabsTrigger>
                  </TabsList>

                  <TabsContent value="osint" className="space-y-4 mt-4">
                    <div className="grid grid-cols-2 gap-4">
                      <Button
                        onClick={() => runTool("shodan")}
                        className="bg-red-600 hover:bg-red-700 justify-start"
                        disabled={activeTools.includes("shodan")}
                      >
                        <Search className="w-4 h-4 mr-2" />
                        {activeTools.includes("shodan") ? "Running..." : "Shodan Scan"}
                      </Button>
                      <Button
                        onClick={() => runTool("spiderfoot")}
                        className="bg-orange-600 hover:bg-orange-700 justify-start"
                        disabled={activeTools.includes("spiderfoot")}
                      >
                        <Globe className="w-4 h-4 mr-2" />
                        {activeTools.includes("spiderfoot") ? "Running..." : "SpiderFoot"}
                      </Button>
                      <Button
                        onClick={() => runTool("maltego")}
                        className="bg-blue-600 hover:bg-blue-700 justify-start"
                        disabled={activeTools.includes("maltego")}
                      >
                        <Network className="w-4 h-4 mr-2" />
                        {activeTools.includes("maltego") ? "Running..." : "Maltego"}
                      </Button>
                      <Button
                        onClick={() => runTool("social")}
                        className="bg-purple-600 hover:bg-purple-700 justify-start"
                        disabled={activeTools.includes("social")}
                      >
                        <Eye className="w-4 h-4 mr-2" />
                        {activeTools.includes("social") ? "Running..." : "Social Media"}
                      </Button>
                    </div>
                  </TabsContent>

                  <TabsContent value="forensics" className="space-y-4 mt-4">
                    <div className="grid grid-cols-2 gap-4">
                      <Button
                        onClick={() => runTool("autopsy")}
                        className="bg-green-600 hover:bg-green-700 justify-start"
                        disabled={activeTools.includes("autopsy")}
                      >
                        <HardDrive className="w-4 h-4 mr-2" />
                        {activeTools.includes("autopsy") ? "Running..." : "Autopsy"}
                      </Button>
                      <Button
                        onClick={() => runTool("ftk")}
                        className="bg-indigo-600 hover:bg-indigo-700 justify-start"
                        disabled={activeTools.includes("ftk")}
                      >
                        <Shield className="w-4 h-4 mr-2" />
                        {activeTools.includes("ftk") ? "Running..." : "FTK Imager"}
                      </Button>
                    </div>
                  </TabsContent>

                  <TabsContent value="network" className="space-y-4 mt-4">
                    <div className="grid grid-cols-2 gap-4">
                      <Button
                        onClick={() => runTool("wireshark")}
                        className="bg-blue-600 hover:bg-blue-700 justify-start"
                        disabled={activeTools.includes("wireshark")}
                      >
                        <Network className="w-4 h-4 mr-2" />
                        {activeTools.includes("wireshark") ? "Running..." : "Wireshark"}
                      </Button>
                      <Button
                        onClick={() => runTool("nmap")}
                        className="bg-green-600 hover:bg-green-700 justify-start"
                        disabled={activeTools.includes("nmap")}
                      >
                        <Search className="w-4 h-4 mr-2" />
                        {activeTools.includes("nmap") ? "Running..." : "Nmap"}
                      </Button>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Evidence */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Evidence Files</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {caseData.evidence.map((file, idx) => (
                  <div key={idx} className="flex items-center justify-between bg-slate-900 p-3 rounded-lg">
                    <div className="flex items-center gap-3">
                      <FileText className="w-4 h-4 text-blue-400" />
                      <div>
                        <p className="text-white text-sm font-medium">{file.name}</p>
                        <p className="text-slate-400 text-xs">{file.size}</p>
                      </div>
                    </div>
                    <Button size="sm" variant="outline" className="bg-slate-700 border-slate-600">
                      <Eye className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Suspect Information */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Suspect Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <p className="text-slate-400 text-sm">Phone Number</p>
                  <p className="text-white font-mono">{caseData.suspect.phone}</p>
                </div>
                <div>
                  <p className="text-slate-400 text-sm">Bank Account</p>
                  <p className="text-white font-mono">{caseData.suspect.bankAccount}</p>
                </div>
                <div>
                  <p className="text-slate-400 text-sm">Location</p>
                  <p className="text-white">{caseData.suspect.location}</p>
                </div>
              </CardContent>
            </Card>

            {/* Active Scans */}
            {activeTools.length > 0 && (
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Clock className="w-5 h-5 animate-spin" />
                    Active Scans
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {activeTools.map((tool, idx) => (
                    <div key={idx} className="flex items-center gap-3 bg-slate-900 p-2 rounded">
                      <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
                      <span className="text-slate-300 text-sm capitalize">{tool} scanning...</span>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
