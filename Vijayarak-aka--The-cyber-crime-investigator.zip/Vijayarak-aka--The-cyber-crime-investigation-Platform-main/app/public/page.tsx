"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Shield, Search, Phone, AlertTriangle, BookOpen, Bot, Scale, MapPin } from "lucide-react"
import Link from "next/link"

export default function PublicPage() {
  const [trackingId, setTrackingId] = useState("")

  const scamTypes = [
    { name: "OTP Scam", count: "45%", color: "bg-red-500" },
    { name: "UPI Fraud", count: "23%", color: "bg-orange-500" },
    { name: "Phishing", count: "18%", color: "bg-yellow-500" },
    { name: "Investment Scam", count: "8%", color: "bg-blue-500" },
    { name: "Job Scam", count: "6%", color: "bg-purple-500" },
  ]

  return (
    <div className="min-h-screen bg-slate-900 text-white">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900/50 to-purple-900/50"></div>
        <div className="relative container mx-auto px-6 py-20">
          <div className="text-center max-w-4xl mx-auto">
            <div className="flex justify-center mb-6">
              <div className="w-20 h-20 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center">
                <Shield className="w-10 h-10 text-white" />
              </div>
            </div>
            <h1 className="text-5xl font-bold mb-6 bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
              CyberRakshak
            </h1>
            <p className="text-xl text-slate-300 mb-8 leading-relaxed">
              भारत सरकार का साइबर अपराध रिपोर्टिंग और जांच मंच
              <br />
              Government of India's Cyber Crime Reporting & Investigation Platform
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/public/report">
                <Button size="lg" className="bg-red-600 hover:bg-red-700 text-white px-8 py-3">
                  <AlertTriangle className="w-5 h-5 mr-2" />
                  Report Cyber Crime
                </Button>
              </Link>
              <Link href="/public/track">
                <Button
                  size="lg"
                  variant="outline"
                  className="border-blue-500 text-blue-400 hover:bg-blue-500 hover:text-white px-8 py-3"
                >
                  <Search className="w-5 h-5 mr-2" />
                  Track Your Case
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 py-12">
        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          <Card className="bg-slate-800 border-slate-700 hover:border-red-500 transition-colors cursor-pointer">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-red-600 rounded-lg flex items-center justify-center mx-auto mb-4">
                <AlertTriangle className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-semibold text-white mb-2">Emergency Report</h3>
              <p className="text-slate-400 text-sm">Report ongoing cyber crime immediately</p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700 hover:border-blue-500 transition-colors cursor-pointer">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Search className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-semibold text-white mb-2">Track Case</h3>
              <p className="text-slate-400 text-sm">Check status of your complaint</p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700 hover:border-green-500 transition-colors cursor-pointer">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-green-600 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Phone className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-semibold text-white mb-2">Helpline</h3>
              <p className="text-slate-400 text-sm">Call 1930 for immediate help</p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700 hover:border-purple-500 transition-colors cursor-pointer">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-purple-600 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Bot className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-semibold text-white mb-2">AI Assistant</h3>
              <p className="text-slate-400 text-sm">Get instant scam analysis</p>
            </CardContent>
          </Card>
        </div>

        {/* Case Tracking */}
        <Card className="bg-slate-800 border-slate-700 mb-12">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Search className="w-5 h-5" />
              Track Your Case
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4">
              <Input
                placeholder="Enter your case ID (e.g., CR2025001)"
                value={trackingId}
                onChange={(e) => setTrackingId(e.target.value)}
                className="bg-slate-900 border-slate-600 text-white"
              />
              <Button className="bg-blue-600 hover:bg-blue-700">
                <Search className="w-4 h-4 mr-2" />
                Track
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Scam Types Statistics */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Common Scam Types in India</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {scamTypes.map((scam, idx) => (
                  <div key={idx} className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`w-3 h-3 rounded-full ${scam.color}`}></div>
                      <span className="text-slate-300">{scam.name}</span>
                    </div>
                    <Badge className="bg-slate-700 text-slate-300">{scam.count}</Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Emergency Contacts</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-3 p-3 bg-slate-900 rounded-lg">
                <Phone className="w-5 h-5 text-red-400" />
                <div>
                  <p className="text-white font-medium">Cyber Crime Helpline</p>
                  <p className="text-slate-400">1930 (24/7 Available)</p>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 bg-slate-900 rounded-lg">
                <Phone className="w-5 h-5 text-blue-400" />
                <div>
                  <p className="text-white font-medium">Police Emergency</p>
                  <p className="text-slate-400">100</p>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 bg-slate-900 rounded-lg">
                <Phone className="w-5 h-5 text-green-400" />
                <div>
                  <p className="text-white font-medium">Women Helpline</p>
                  <p className="text-slate-400">181</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Services */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <BookOpen className="w-5 h-5" />
                Awareness Center
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-400 mb-4">
                Learn about different types of cyber crimes and how to protect yourself.
              </p>
              <Button variant="outline" className="border-slate-600 text-slate-300 hover:bg-slate-700">
                Learn More
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Scale className="w-5 h-5" />
                Legal Aid
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-400 mb-4">Get guidance on filing FIR and legal procedures for cyber crimes.</p>
              <Button variant="outline" className="border-slate-600 text-slate-300 hover:bg-slate-700">
                Get Help
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <MapPin className="w-5 h-5" />
                Hacker Tracer
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-400 mb-4">Advanced tools to trace and locate cyber criminals.</p>
              <Button variant="outline" className="border-slate-600 text-slate-300 hover:bg-slate-700">
                Access Tools
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
