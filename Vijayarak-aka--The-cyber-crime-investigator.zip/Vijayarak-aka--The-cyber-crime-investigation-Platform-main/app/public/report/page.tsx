"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Upload, FileText, ImageIcon, AlertCircle, IndianRupee } from "lucide-react"

export default function ReportPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    alternatePhone: "",
    address: "",
    state: "",
    district: "",
    scamType: "",
    incidentDate: "",
    incidentTime: "",
    description: "",
    suspectDetails: "",
    amountLost: "",
    bankDetails: "",
    transactionId: "",
    urgency: "medium",
    language: "english",
  })

  const [files, setFiles] = useState<File[]>([])
  const [isSubmitting, setIsSubmitting] = useState(false)

  const scamTypes = [
    "OTP Fraud/SMS Fraud",
    "UPI/Payment Fraud",
    "Phishing/Fake Websites",
    "Investment/Trading Scam",
    "Job Offer/Work from Home Scam",
    "Fake Loan Apps Scam",
    "Sextortion/Romance Scam",
    "Fake Tech Support Scam",
    "Online Shopping Scam",
    "Fake Electricity Bill Scam",
    "Telegram/WhatsApp Scam",
    "Cryptocurrency Scam",
    "Other",
  ]

  const indianStates = [
    "Andhra Pradesh",
    "Arunachal Pradesh",
    "Assam",
    "Bihar",
    "Chhattisgarh",
    "Goa",
    "Gujarat",
    "Haryana",
    "Himachal Pradesh",
    "Jharkhand",
    "Karnataka",
    "Kerala",
    "Madhya Pradesh",
    "Maharashtra",
    "Manipur",
    "Meghalaya",
    "Mizoram",
    "Nagaland",
    "Odisha",
    "Punjab",
    "Rajasthan",
    "Sikkim",
    "Tamil Nadu",
    "Telangana",
    "Tripura",
    "Uttar Pradesh",
    "Uttarakhand",
    "West Bengal",
    "Delhi",
    "Jammu and Kashmir",
    "Ladakh",
    "Puducherry",
    "Chandigarh",
    "Andaman and Nicobar Islands",
    "Dadra and Nagar Haveli",
    "Daman and Diu",
    "Lakshadweep",
  ]

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Generate case ID
    const caseId = `CR${new Date().getFullYear()}${String(Date.now()).slice(-6)}`

    // Simulate API call
    setTimeout(() => {
      alert(
        `Your complaint has been registered successfully!\nCase ID: ${caseId}\nPlease save this ID for tracking your case.`,
      )
      setIsSubmitting(false)
      // Reset form or redirect
    }, 2000)
  }

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFiles(Array.from(e.target.files))
    }
  }

  return (
    <div className="min-h-screen bg-slate-900 text-white">
      <div className="container mx-auto p-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-red-400 to-orange-500 bg-clip-text text-transparent">
            Report Cyber Crime
          </h1>
          <p className="text-slate-400 text-lg">
            साइबर अपराध की रिपोर्ट करें - Help us protect others from cyber criminals
          </p>
          <div className="flex items-center gap-2 mt-4 p-3 bg-red-900/20 border border-red-500/30 rounded-lg">
            <AlertCircle className="w-5 h-5 text-red-400" />
            <p className="text-red-300 text-sm">
              For immediate emergency, call 1930 (Cyber Crime Helpline) or 100 (Police)
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Personal Information */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <AlertCircle className="w-5 h-5 text-blue-400" />
                  Personal Information / व्यक्तिगत जानकारी
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="name" className="text-slate-300">
                    Full Name / पूरा नाम *
                  </Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="bg-slate-900 border-slate-600 text-white"
                    placeholder="Enter your full name"
                    required
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="email" className="text-slate-300">
                      Email Address / ईमेल *
                    </Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="bg-slate-900 border-slate-600 text-white"
                      placeholder="your@email.com"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="phone" className="text-slate-300">
                      Mobile Number / मोबाइल नंबर *
                    </Label>
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="bg-slate-900 border-slate-600 text-white"
                      placeholder="+91-XXXXXXXXXX"
                      required
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="address" className="text-slate-300">
                    Address / पता *
                  </Label>
                  <Textarea
                    id="address"
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    className="bg-slate-900 border-slate-600 text-white"
                    placeholder="Complete address with pin code"
                    rows={3}
                    required
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="state" className="text-slate-300">
                      State / राज्य *
                    </Label>
                    <Select onValueChange={(value) => setFormData({ ...formData, state: value })}>
                      <SelectTrigger className="bg-slate-900 border-slate-600 text-white">
                        <SelectValue placeholder="Select your state" />
                      </SelectTrigger>
                      <SelectContent className="bg-slate-800 border-slate-600">
                        {indianStates.map((state) => (
                          <SelectItem key={state} value={state}>
                            {state}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="district" className="text-slate-300">
                      District / जिला *
                    </Label>
                    <Input
                      id="district"
                      value={formData.district}
                      onChange={(e) => setFormData({ ...formData, district: e.target.value })}
                      className="bg-slate-900 border-slate-600 text-white"
                      placeholder="Enter your district"
                      required
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Incident Details */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <AlertCircle className="w-5 h-5 text-red-400" />
                  Incident Details / घटना का विवरण
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="scamType" className="text-slate-300">
                    Type of Scam / धोखाधड़ी का प्रकार *
                  </Label>
                  <Select onValueChange={(value) => setFormData({ ...formData, scamType: value })}>
                    <SelectTrigger className="bg-slate-900 border-slate-600 text-white">
                      <SelectValue placeholder="Select scam type" />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-800 border-slate-600">
                      {scamTypes.map((type) => (
                        <SelectItem key={type} value={type}>
                          {type}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="incidentDate" className="text-slate-300">
                      Date of Incident / घटना की तारीख *
                    </Label>
                    <Input
                      id="incidentDate"
                      type="date"
                      value={formData.incidentDate}
                      onChange={(e) => setFormData({ ...formData, incidentDate: e.target.value })}
                      className="bg-slate-900 border-slate-600 text-white"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="incidentTime" className="text-slate-300">
                      Time of Incident / समय
                    </Label>
                    <Input
                      id="incidentTime"
                      type="time"
                      value={formData.incidentTime}
                      onChange={(e) => setFormData({ ...formData, incidentTime: e.target.value })}
                      className="bg-slate-900 border-slate-600 text-white"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="amountLost" className="text-slate-300">
                    Amount Lost / नुकसान की राशि (₹)
                  </Label>
                  <div className="relative">
                    <IndianRupee className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                    <Input
                      id="amountLost"
                      type="number"
                      value={formData.amountLost}
                      onChange={(e) => setFormData({ ...formData, amountLost: e.target.value })}
                      className="bg-slate-900 border-slate-600 text-white pl-10"
                      placeholder="Enter amount in rupees"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="transactionId" className="text-slate-300">
                    Transaction ID / UPI Reference Number
                  </Label>
                  <Input
                    id="transactionId"
                    value={formData.transactionId}
                    onChange={(e) => setFormData({ ...formData, transactionId: e.target.value })}
                    className="bg-slate-900 border-slate-600 text-white"
                    placeholder="Enter transaction/UPI reference number"
                  />
                </div>

                <div>
                  <Label htmlFor="urgency" className="text-slate-300">
                    Urgency Level / तात्कालिकता *
                  </Label>
                  <Select onValueChange={(value) => setFormData({ ...formData, urgency: value })}>
                    <SelectTrigger className="bg-slate-900 border-slate-600 text-white">
                      <SelectValue placeholder="Select urgency level" />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-800 border-slate-600">
                      <SelectItem value="low">Low - Past incident</SelectItem>
                      <SelectItem value="medium">Medium - Recent incident</SelectItem>
                      <SelectItem value="high">High - Ongoing scam</SelectItem>
                      <SelectItem value="critical">Critical - Emergency</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Detailed Description */}
          <Card className="bg-slate-800 border-slate-700 mt-8">
            <CardHeader>
              <CardTitle className="text-white">Detailed Description / विस्तृत विवरण</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="description" className="text-slate-300">
                  Describe the incident in detail / घटना का विस्तृत विवरण *
                </Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="bg-slate-900 border-slate-600 text-white mt-2"
                  placeholder="Please describe what happened - how you were contacted, what they said, what you did, etc. / कृपया बताएं कि क्या हुआ था - आपसे कैसे संपर्क किया गया, उन्होंने क्या कहा, आपने क्या किया, आदि।"
                  rows={6}
                  required
                />
              </div>

              <div>
                <Label htmlFor="suspectDetails" className="text-slate-300">
                  Suspect Details / संदिग्ध की जानकारी
                </Label>
                <Textarea
                  id="suspectDetails"
                  value={formData.suspectDetails}
                  onChange={(e) => setFormData({ ...formData, suspectDetails: e.target.value })}
                  className="bg-slate-900 border-slate-600 text-white mt-2"
                  placeholder="Phone numbers, email addresses, bank account details, UPI IDs, social media profiles, etc. / फोन नंबर, ईमेल पते, बैंक खाता विवरण, UPI आईडी, सोशल मीडिया प्रोफाइल, आदि।"
                  rows={4}
                />
              </div>
            </CardContent>
          </Card>

          {/* Evidence Upload */}
          <Card className="bg-slate-800 border-slate-700 mt-8">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Upload className="w-5 h-5" />
                Evidence Upload / सबूत अपलोड करें
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="border-2 border-dashed border-slate-600 rounded-lg p-8 text-center">
                <input
                  type="file"
                  multiple
                  accept=".pdf,.jpg,.jpeg,.png,.txt,.doc,.docx,.mp3,.mp4,.wav"
                  onChange={handleFileUpload}
                  className="hidden"
                  id="file-upload"
                />
                <label htmlFor="file-upload" className="cursor-pointer">
                  <Upload className="w-16 h-16 text-slate-400 mx-auto mb-4" />
                  <p className="text-slate-300 mb-2 text-lg">Click to upload evidence files</p>
                  <p className="text-slate-500">Screenshots, call recordings, messages, documents, videos</p>
                  <p className="text-slate-500 text-sm mt-2">
                    स्क्रीनशॉट, कॉल रिकॉर्डिंग, संदेश, दस्तावेज, वीडियो (Max 25MB each)
                  </p>
                </label>
              </div>

              {files.length > 0 && (
                <div className="mt-6 space-y-3">
                  <p className="text-slate-300 font-medium">Uploaded Files:</p>
                  {files.map((file, index) => (
                    <div key={index} className="flex items-center gap-3 bg-slate-900 p-3 rounded-lg">
                      {file.type.startsWith("image/") ? (
                        <ImageIcon className="w-5 h-5 text-blue-400" />
                      ) : (
                        <FileText className="w-5 h-5 text-green-400" />
                      )}
                      <div className="flex-1">
                        <span className="text-slate-300">{file.name}</span>
                        <span className="text-slate-500 text-sm ml-2">({(file.size / 1024 / 1024).toFixed(2)} MB)</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Terms and Submit */}
          <Card className="bg-slate-800 border-slate-700 mt-8">
            <CardContent className="p-6">
              <div className="space-y-4">
                <div className="flex items-start space-x-2">
                  <Checkbox id="terms" className="mt-1" />
                  <label htmlFor="terms" className="text-sm text-slate-300 leading-relaxed">
                    I hereby declare that the information provided above is true and correct to the best of my
                    knowledge. I understand that providing false information is a punishable offense under Indian law.
                    <br />
                    <span className="text-slate-400">
                      मैं घोषणा करता/करती हूं कि ऊपर दी गई जानकारी मेरी जानकारी के अनुसार सत्य और सही है। मैं समझता/समझती हूं कि झूठी
                      जानकारी देना भारतीय कानून के तहत दंडनीय अपराध है।
                    </span>
                  </label>
                </div>

                <div className="flex justify-center pt-4">
                  <Button
                    type="submit"
                    size="lg"
                    className="bg-red-600 hover:bg-red-700 text-white px-12 py-4 text-lg"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      <>
                        <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                        Submitting...
                      </>
                    ) : (
                      <>
                        <FileText className="w-5 h-5 mr-2" />
                        Submit Complaint / शिकायत दर्ज करें
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </form>
      </div>
    </div>
  )
}
