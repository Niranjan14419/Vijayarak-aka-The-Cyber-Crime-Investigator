"use client"

import { useEffect, useState } from "react"
import { DashboardStats } from "@/components/dashboard-stats"
import { IndianCaseMap } from "@/components/indian-case-map"
import { RecentCases } from "@/components/recent-cases"
import { CaseChart } from "@/components/case-chart"
import { ScamTypeChart } from "@/components/scam-type-chart"
import { AIAssistant } from "@/components/ai-assistant"

export default function Dashboard() {
  const [currentTime, setCurrentTime] = useState(new Date())

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  const formatDateTime = (date: Date) => {
    return date.toLocaleDateString("en-IN", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      timeZone: "Asia/Kolkata",
    })
  }

  return (
    <div className="min-h-screen bg-slate-900 text-white">
      <div className="container mx-auto p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-lg">VR</span>
            </div>
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
                Vijayarakṣaka
   Dashboard
              </h1>
              <p className="text-slate-400">Government Cyber Crime Investigation Platform</p>
            </div>
          </div>
          <div className="flex items-center gap-4 text-sm">
            <div className="bg-slate-800 px-4 py-2 rounded-lg border border-slate-700">
              <span className="text-slate-400">Current Time (IST): </span>
              <span className="text-white font-mono">{formatDateTime(currentTime)}</span>
            </div>
            <select className="bg-slate-800 border border-slate-700 rounded px-3 py-2 text-white">
              <option>Last 30 days</option>
              <option>Last 7 days</option>
              <option>Last 24 hours</option>
            </select>
          </div>
        </div>

        {/* Stats Cards */}
        <DashboardStats />

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-8">
          {/* Indian Case Map */}
          <div className="lg:col-span-2">
            <IndianCaseMap />
          </div>

          {/* Recent Cases */}
          <div>
            <RecentCases />
          </div>
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">
          <CaseChart />
          <ScamTypeChart />
        </div>
      </div>

      {/* AI Assistant */}
      <AIAssistant />
    </div>
  )
}
