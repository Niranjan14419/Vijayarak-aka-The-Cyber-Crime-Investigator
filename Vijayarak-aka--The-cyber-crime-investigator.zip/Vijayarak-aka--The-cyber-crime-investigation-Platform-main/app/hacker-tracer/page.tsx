"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MapPin, Search, Globe, Smartphone, Wifi, Shield, AlertTriangle, Clock, Target, Zap } from "lucide-react"

export default function HackerTracerPage() {
  const [traceResults, setTraceResults] = useState<any>(null)
  const [isTracing, setIsTracing] = useState(false)
  const [traceInput, setTraceInput] = useState("")

  const startTrace = async (type: string, input: string) => {
    setIsTracing(true)
    setTraceInput(input)

    // Simulate tracing process
    setTimeout(() => {
      const mockResults = {
        ip: {
          address: input,
          location: "Mumbai, Maharashtra, India",
          coordinates: { lat: 19.076, lng: 72.8777 },
          isp: "Reliance Jio Infocomm Limited",
          organization: "Jio",
          timezone: "Asia/Kolkata",
          threat_level: "Medium",
          vpn_detected: false,
          proxy_detected: true,
          tor_detected: false,
        },
        phone: {
          number: input,
          carrier: "Airtel",
          location: "Delhi, India",
          type: "Mobile",
          valid: true,
          risk_score: 75,
          reported_spam: true,
          last_seen: "2 hours ago",
        },
        email: {
          address: input,
          domain: input.split("@")[1],
          valid: true,
          disposable: false,
          risk_score: 60,
          breach_count: 2,
          social_media: ["telegram", "whatsapp"],
        },
      }

      setTraceResults(mockResults[type as keyof typeof mockResults])
      setIsTracing(false)
    }, 3000)
  }

  return (
    <div className="min-h-screen bg-slate-900 text-white">
      <div className="container mx-auto p-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-red-400 to-orange-500 bg-clip-text text-transparent">
            Hacker Location Tracer
          </h1>
          <p className="text-slate-400 text-lg">Advanced tools to trace and locate cyber criminals</p>
          <div className="flex items-center gap-2 mt-4 p-3 bg-yellow-900/20 border border-yellow-500/30 rounded-lg">
            <AlertTriangle className="w-5 h-5 text-yellow-400" />
            <p className="text-yellow-300 text-sm">
              This tool is for authorized law enforcement use only. Misuse is punishable under IT Act 2000.
            </p>
          </div>
        </div>

        <Tabs defaultValue="ip-trace" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-slate-800 border border-slate-700">
            <TabsTrigger value="ip-trace" className="data-[state=active]:bg-red-600">
              IP Tracer
            </TabsTrigger>
            <TabsTrigger value="phone-trace" className="data-[state=active]:bg-blue-600">
              Phone Tracer
            </TabsTrigger>
            <TabsTrigger value="email-trace" className="data-[state=active]:bg-green-600">
              Email Tracer
            </TabsTrigger>
            <TabsTrigger value="advanced" className="data-[state=active]:bg-purple-600">
              Advanced Tools
            </TabsTrigger>
          </TabsList>

          {/* IP Tracer */}
          <TabsContent value="ip-trace">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Globe className="w-5 h-5" />
                    IP Address Tracer
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label className="text-slate-300">IP Address</Label>
                    <Input
                      placeholder="192.168.1.1 or domain.com"
                      className="bg-slate-900 border-slate-600 text-white"
                      onChange={(e) => setTraceInput(e.target.value)}
                    />
                  </div>
                  <Button
                    onClick={() => startTrace("ip", traceInput)}
                    className="w-full bg-red-600 hover:bg-red-700"
                    disabled={isTracing || !traceInput}
                  >
                    {isTracing ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Tracing...
                      </>
                    ) : (
                      <>
                        <Target className="w-4 h-4 mr-2" />
                        Start IP Trace
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>

              {traceResults && (
                <Card className="bg-slate-800 border-slate-700">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <MapPin className="w-5 h-5" />
                      Trace Results
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-slate-400 text-sm">Location</p>
                        <p className="text-white font-medium">{traceResults.location}</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-sm">ISP</p>
                        <p className="text-white font-medium">{traceResults.isp}</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-sm">Timezone</p>
                        <p className="text-white font-medium">{traceResults.timezone}</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-sm">Threat Level</p>
                        <Badge
                          className={`${
                            traceResults.threat_level === "High"
                              ? "bg-red-500/20 text-red-400"
                              : traceResults.threat_level === "Medium"
                                ? "bg-yellow-500/20 text-yellow-400"
                                : "bg-green-500/20 text-green-400"
                          }`}
                        >
                          {traceResults.threat_level}
                        </Badge>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <p className="text-slate-400 text-sm">Security Flags</p>
                      <div className="flex flex-wrap gap-2">
                        <Badge
                          className={`${traceResults.vpn_detected ? "bg-red-500/20 text-red-400" : "bg-green-500/20 text-green-400"}`}
                        >
                          VPN: {traceResults.vpn_detected ? "Detected" : "Not Detected"}
                        </Badge>
                        <Badge
                          className={`${traceResults.proxy_detected ? "bg-red-500/20 text-red-400" : "bg-green-500/20 text-green-400"}`}
                        >
                          Proxy: {traceResults.proxy_detected ? "Detected" : "Not Detected"}
                        </Badge>
                        <Badge
                          className={`${traceResults.tor_detected ? "bg-red-500/20 text-red-400" : "bg-green-500/20 text-green-400"}`}
                        >
                          Tor: {traceResults.tor_detected ? "Detected" : "Not Detected"}
                        </Badge>
                      </div>
                    </div>

                    {/* Mock Map */}
                    <div className="bg-slate-900 p-4 rounded-lg">
                      <div className="h-48 bg-slate-700 rounded flex items-center justify-center">
                        <div className="text-center">
                          <MapPin className="w-8 h-8 text-red-400 mx-auto mb-2" />
                          <p className="text-slate-300">Location: {traceResults.location}</p>
                          <p className="text-slate-400 text-sm">
                            Coordinates: {traceResults.coordinates?.lat}, {traceResults.coordinates?.lng}
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          {/* Phone Tracer */}
          <TabsContent value="phone-trace">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Smartphone className="w-5 h-5" />
                    Phone Number Tracer
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label className="text-slate-300">Phone Number</Label>
                    <Input
                      placeholder="+91-9876543210"
                      className="bg-slate-900 border-slate-600 text-white"
                      onChange={(e) => setTraceInput(e.target.value)}
                    />
                  </div>
                  <Button
                    onClick={() => startTrace("phone", traceInput)}
                    className="w-full bg-blue-600 hover:bg-blue-700"
                    disabled={isTracing || !traceInput}
                  >
                    {isTracing ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Tracing...
                      </>
                    ) : (
                      <>
                        <Search className="w-4 h-4 mr-2" />
                        Trace Phone Number
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>

              {traceResults && (
                <Card className="bg-slate-800 border-slate-700">
                  <CardHeader>
                    <CardTitle className="text-white">Phone Trace Results</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-slate-400 text-sm">Carrier</p>
                        <p className="text-white font-medium">{traceResults.carrier}</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-sm">Location</p>
                        <p className="text-white font-medium">{traceResults.location}</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-sm">Type</p>
                        <p className="text-white font-medium">{traceResults.type}</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-sm">Risk Score</p>
                        <Badge
                          className={`${
                            traceResults.risk_score > 70
                              ? "bg-red-500/20 text-red-400"
                              : traceResults.risk_score > 40
                                ? "bg-yellow-500/20 text-yellow-400"
                                : "bg-green-500/20 text-green-400"
                          }`}
                        >
                          {traceResults.risk_score}/100
                        </Badge>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400">Valid Number</span>
                        <Badge
                          className={`${traceResults.valid ? "bg-green-500/20 text-green-400" : "bg-red-500/20 text-red-400"}`}
                        >
                          {traceResults.valid ? "Valid" : "Invalid"}
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400">Reported as Spam</span>
                        <Badge
                          className={`${traceResults.reported_spam ? "bg-red-500/20 text-red-400" : "bg-green-500/20 text-green-400"}`}
                        >
                          {traceResults.reported_spam ? "Yes" : "No"}
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400">Last Seen</span>
                        <span className="text-white">{traceResults.last_seen}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          {/* Email Tracer */}
          <TabsContent value="email-trace">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Shield className="w-5 h-5" />
                    Email Address Tracer
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label className="text-slate-300">Email Address</Label>
                    <Input
                      placeholder="suspect@example.com"
                      className="bg-slate-900 border-slate-600 text-white"
                      onChange={(e) => setTraceInput(e.target.value)}
                    />
                  </div>
                  <Button
                    onClick={() => startTrace("email", traceInput)}
                    className="w-full bg-green-600 hover:bg-green-700"
                    disabled={isTracing || !traceInput}
                  >
                    {isTracing ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Analyzing...
                      </>
                    ) : (
                      <>
                        <Search className="w-4 h-4 mr-2" />
                        Analyze Email
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>

              {traceResults && (
                <Card className="bg-slate-800 border-slate-700">
                  <CardHeader>
                    <CardTitle className="text-white">Email Analysis Results</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-slate-400 text-sm">Domain</p>
                        <p className="text-white font-medium">{traceResults.domain}</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-sm">Risk Score</p>
                        <Badge
                          className={`${
                            traceResults.risk_score > 70
                              ? "bg-red-500/20 text-red-400"
                              : traceResults.risk_score > 40
                                ? "bg-yellow-500/20 text-yellow-400"
                                : "bg-green-500/20 text-green-400"
                          }`}
                        >
                          {traceResults.risk_score}/100
                        </Badge>
                      </div>
                      <div>
                        <p className="text-slate-400 text-sm">Data Breaches</p>
                        <p className="text-white font-medium">{traceResults.breach_count} found</p>
                      </div>
                      <div>
                        <p className="text-slate-400 text-sm">Disposable Email</p>
                        <Badge
                          className={`${traceResults.disposable ? "bg-red-500/20 text-red-400" : "bg-green-500/20 text-green-400"}`}
                        >
                          {traceResults.disposable ? "Yes" : "No"}
                        </Badge>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <p className="text-slate-400 text-sm">Associated Social Media</p>
                      <div className="flex flex-wrap gap-2">
                        {traceResults.social_media?.map((platform: string, idx: number) => (
                          <Badge key={idx} className="bg-blue-500/20 text-blue-400">
                            {platform}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          {/* Advanced Tools */}
          <TabsContent value="advanced">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Wifi className="w-5 h-5" />
                    Network Scanner
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-slate-400 text-sm">Scan network ranges for suspicious activities</p>
                  <Button className="w-full bg-purple-600 hover:bg-purple-700">
                    <Zap className="w-4 h-4 mr-2" />
                    Launch Network Scan
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Target className="w-5 h-5" />
                    Social Media Tracer
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-slate-400 text-sm">Find social media profiles linked to suspects</p>
                  <Button className="w-full bg-indigo-600 hover:bg-indigo-700">
                    <Search className="w-4 h-4 mr-2" />
                    Search Profiles
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Clock className="w-5 h-5" />
                    Digital Footprint
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-slate-400 text-sm">Analyze digital footprint and online activities</p>
                  <Button className="w-full bg-teal-600 hover:bg-teal-700">
                    <Shield className="w-4 h-4 mr-2" />
                    Analyze Footprint
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
